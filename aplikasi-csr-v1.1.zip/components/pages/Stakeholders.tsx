
import React from 'react';

const Stakeholders: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800">Pemangku Kepentingan</h1>
      <p className="mt-2 text-gray-600">Kelola data pemangku kepentingan di sini.</p>
    </div>
  );
};

export default Stakeholders;
