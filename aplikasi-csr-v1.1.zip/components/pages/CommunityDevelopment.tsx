
import React from 'react';

const CommunityDevelopment: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800">Pengembangan Masyarakat</h1>
      <p className="mt-2 text-gray-600">Kelola program pengembangan masyarakat di sini.</p>
    </div>
  );
};

export default CommunityDevelopment;
